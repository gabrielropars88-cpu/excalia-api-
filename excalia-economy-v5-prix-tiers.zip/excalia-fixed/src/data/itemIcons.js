// Icônes Minecraft depuis minecraft.wiki
export const ITEM_ICONS = {
  // Fer
  iron_ingot: 'https://minecraft.wiki/images/Iron_Ingot_JE3_BE2.png',
  iron_block: 'https://minecraft.wiki/images/Block_of_Iron_JE4_BE3.png',
  iron_ore: 'https://minecraft.wiki/images/Iron_Ore_JE4_BE3.png',
  raw_iron: 'https://minecraft.wiki/images/Raw_Iron_JE2_BE2.png',
  iron_nugget: 'https://minecraft.wiki/images/Iron_Nugget_JE2_BE1.png',
  // Or
  gold_ingot: 'https://minecraft.wiki/images/Gold_Ingot_JE4_BE2.png',
  gold_block: 'https://minecraft.wiki/images/Block_of_Gold_JE6_BE3.png',
  gold_ore: 'https://minecraft.wiki/images/Gold_Ore_JE4_BE2.png',
  raw_gold: 'https://minecraft.wiki/images/Raw_Gold_JE2_BE2.png',
  gold_nugget: 'https://minecraft.wiki/images/Gold_Nugget_JE2_BE1.png',
  // Cuivre
  copper_ingot: 'https://minecraft.wiki/images/Copper_Ingot_JE2_BE1.png',
  copper_block: 'https://minecraft.wiki/images/Block_of_Copper_JE2_BE1.png',
  copper_ore: 'https://minecraft.wiki/images/Copper_Ore_JE3_BE3.png',
  raw_copper: 'https://minecraft.wiki/images/Raw_Copper_JE2_BE2.png',
  // Charbon
  coal: 'https://minecraft.wiki/images/Coal_JE4_BE3.png',
  coal_block: 'https://minecraft.wiki/images/Block_of_Coal_JE2_BE2.png',
  coal_ore: 'https://minecraft.wiki/images/Coal_Ore_JE4_BE3.png',
  // Diamant
  diamond: 'https://minecraft.wiki/images/Diamond_JE3_BE3.png',
  diamond_block: 'https://minecraft.wiki/images/Block_of_Diamond_JE5_BE3.png',
  diamond_ore: 'https://minecraft.wiki/images/Diamond_Ore_JE4_BE3.png',
  deepslate_diamond_ore: 'https://minecraft.wiki/images/Deepslate_Diamond_Ore_JE2_BE1.png',
  // Émeraude
  emerald: 'https://minecraft.wiki/images/Emerald_JE3_BE3.png',
  emerald_block: 'https://minecraft.wiki/images/Block_of_Emerald_JE4_BE3.png',
  emerald_ore: 'https://minecraft.wiki/images/Emerald_Ore_JE4_BE3.png',
  // Redstone
  redstone: 'https://minecraft.wiki/images/Redstone_Dust_JE2_BE2.png',
  redstone_block: 'https://minecraft.wiki/images/Block_of_Redstone_JE2_BE2.png',
  redstone_ore: 'https://minecraft.wiki/images/Redstone_Ore_JE3_BE3.png',
  // Lapis
  lapis_lazuli: 'https://minecraft.wiki/images/Lapis_Lazuli_JE1_BE1.png',
  lapis_block: 'https://minecraft.wiki/images/Lapis_Lazuli_Block_JE3_BE3.png',
  lapis_ore: 'https://minecraft.wiki/images/Lapis_Lazuli_Ore_JE4_BE3.png',
  // Quartz
  quartz: 'https://minecraft.wiki/images/Nether_Quartz_JE2_BE2.png',
  quartz_block: 'https://minecraft.wiki/images/Block_of_Quartz_JE5_BE3.png',
  nether_quartz_ore: 'https://minecraft.wiki/images/Nether_Quartz_Ore_JE3_BE2.png',
  // Netherite
  netherite_ingot: 'https://minecraft.wiki/images/Netherite_Ingot_JE2_BE1.png',
  netherite_block: 'https://minecraft.wiki/images/Block_of_Netherite_JE1_BE1.png',
  ancient_debris: 'https://minecraft.wiki/images/Ancient_Debris_JE2_BE1.png',
  netherite_scrap: 'https://minecraft.wiki/images/Netherite_Scrap_JE2_BE1.png',
  // Amethyst
  amethyst_shard: 'https://minecraft.wiki/images/Amethyst_Shard_JE3_BE3.png',
  amethyst_block: 'https://minecraft.wiki/images/Block_of_Amethyst_JE2_BE2.png',
  // Nourriture & farm
  wheat: 'https://minecraft.wiki/images/Wheat_JE2_BE1.png',
  bread: 'https://minecraft.wiki/images/Bread_JE2_BE2.png',
  carrot: 'https://minecraft.wiki/images/Carrot_JE2_BE2.png',
  potato: 'https://minecraft.wiki/images/Potato_JE2_BE2.png',
  apple: 'https://minecraft.wiki/images/Apple_JE3_BE3.png',
  golden_apple: 'https://minecraft.wiki/images/Golden_Apple_JE2_BE2.png',
  enchanted_golden_apple: 'https://minecraft.wiki/images/Enchanted_Golden_Apple_JE3_BE3.png',
  // Mob drops
  bone: 'https://minecraft.wiki/images/Bone_JE3_BE3.png',
  bone_meal: 'https://minecraft.wiki/images/Bone_Meal_JE3_BE3.png',
  string: 'https://minecraft.wiki/images/String_JE3_BE2.png',
  spider_eye: 'https://minecraft.wiki/images/Spider_Eye_JE3_BE3.png',
  gunpowder: 'https://minecraft.wiki/images/Gunpowder_JE3_BE3.png',
  rotten_flesh: 'https://minecraft.wiki/images/Rotten_Flesh_JE3_BE3.png',
  ender_pearl: 'https://minecraft.wiki/images/Ender_Pearl_JE3_BE3.png',
  blaze_rod: 'https://minecraft.wiki/images/Blaze_Rod_JE3_BE3.png',
  blaze_powder: 'https://minecraft.wiki/images/Blaze_Powder_JE3_BE3.png',
  ghast_tear: 'https://minecraft.wiki/images/Ghast_Tear_JE3_BE3.png',
  magma_cream: 'https://minecraft.wiki/images/Magma_Cream_JE3_BE3.png',
  slime_ball: 'https://minecraft.wiki/images/Slimeball_JE3_BE3.png',
  leather: 'https://minecraft.wiki/images/Leather_JE3_BE3.png',
  feather: 'https://minecraft.wiki/images/Feather_JE3_BE3.png',
  ink_sac: 'https://minecraft.wiki/images/Ink_Sac_JE3_BE2.png',
  glow_ink_sac: 'https://minecraft.wiki/images/Glow_Ink_Sac_JE2_BE1.png',
  nether_star: 'https://minecraft.wiki/images/Nether_Star_JE3_BE3.png',
  totem_of_undying: 'https://minecraft.wiki/images/Totem_of_Undying_JE2_BE2.png',
  shulker_shell: 'https://minecraft.wiki/images/Shulker_Shell_JE2_BE1.png',
  elytra: 'https://minecraft.wiki/images/Elytra_JE3_BE3.png',
  // Nether
  glowstone: 'https://minecraft.wiki/images/Glowstone_JE4_BE2.png',
  glowstone_dust: 'https://minecraft.wiki/images/Glowstone_Dust_JE3_BE3.png',
  soul_sand: 'https://minecraft.wiki/images/Soul_Sand_JE5_BE4.png',
  nether_wart: 'https://minecraft.wiki/images/Nether_Wart_JE2_BE2.png',
  nether_brick: 'https://minecraft.wiki/images/Nether_Brick_(item)_JE2_BE2.png',
  blackstone: 'https://minecraft.wiki/images/Blackstone_JE1_BE1.png',
  basalt: 'https://minecraft.wiki/images/Basalt_JE3_BE1.png',
};

export function getItemIcon(type) {
  return ITEM_ICONS[type] ?? null;
}
