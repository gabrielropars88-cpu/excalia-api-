/**
 * itemDisplay.js — Noms FR des items Minecraft
 * Règles : jamais "lingot" pour diamant/émeraude/lapis/quartz/redstone/charbon
 */

const NAME_MAP = {
  // Fer
  iron_ingot: 'Lingot de fer', iron_block: 'Bloc de fer',
  iron_ore: 'Minerai de fer', raw_iron: 'Fer brut',
  iron_nugget: 'Pépite de fer',
  iron_t1: 'Fer compressé T1', iron_t2: 'Fer compressé T2',
  iron_t3: 'Fer compressé T3', iron_t4: 'Fer compressé T4',
  // Or
  gold_ingot: "Lingot d'or", gold_block: "Bloc d'or",
  gold_ore: "Minerai d'or", raw_gold: 'Or brut',
  gold_nugget: "Pépite d'or",
  gold_t1: 'Or compressé T1', gold_t2: 'Or compressé T2', gold_t3: 'Or compressé T3',
  // Cuivre
  copper_ingot: 'Lingot de cuivre', copper_block: 'Bloc de cuivre',
  copper_ore: 'Minerai de cuivre', raw_copper: 'Cuivre brut',
  copper_t1: 'Cuivre compressé T1', copper_t2: 'Cuivre compressé T2',
  // Charbon (pas lingot)
  coal: 'Charbon', coal_block: 'Bloc de charbon', coal_ore: 'Minerai de charbon',
  coal_t1: 'Charbon compressé T1',
  // Diamant (pas lingot)
  diamond: 'Diamant', diamond_block: 'Bloc de diamant',
  diamond_ore: 'Minerai de diamant', deepslate_diamond_ore: 'Minerai de diamant (ardoise)',
  diamond_t1: 'Diamant compressé T1', diamond_t2: 'Diamant compressé T2',
  // Émeraude (pas lingot)
  emerald: 'Émeraude', emerald_block: "Bloc d'émeraude",
  emerald_ore: "Minerai d'émeraude", deepslate_emerald_ore: "Minerai d'émeraude (ardoise)",
  emerald_t1: 'Émeraude compressée T1',
  // Redstone (pas lingot)
  redstone: 'Redstone', redstone_block: 'Bloc de redstone',
  redstone_ore: 'Minerai de redstone', deepslate_redstone_ore: 'Minerai de redstone (ardoise)',
  redstone_t1: 'Redstone compressé T1',
  // Lapis-lazuli (pas lingot)
  lapis_lazuli: 'Lapis-lazuli', lapis_block: 'Bloc de lapis-lazuli',
  lapis_ore: 'Minerai de lapis-lazuli', deepslate_lapis_ore: 'Minerai de lapis (ardoise)',
  lapis_t1: 'Lapis compressé T1',
  // Quartz (pas lingot)
  quartz: 'Quartz', quartz_block: 'Bloc de quartz',
  nether_quartz_ore: 'Minerai de quartz (Nether)',
  // Netherite (lingot pour le lingot)
  netherite_ingot: 'Lingot de netherite', netherite_block: 'Bloc de netherite',
  ancient_debris: 'Vieux débris', netherite_scrap: 'Débris de netherite',
  // Amethyst
  amethyst_shard: 'Éclat d\'améthyste', amethyst_block: 'Bloc d\'améthyste',
  budding_amethyst: 'Améthyste en croissance',
  // Bois
  oak_log: 'Bûche de chêne', birch_log: 'Bûche de bouleau',
  spruce_log: 'Bûche d\'épicéa', jungle_log: 'Bûche de jungle',
  acacia_log: 'Bûche d\'acacia', dark_oak_log: 'Bûche de chêne noir',
  mangrove_log: 'Bûche de palétuviers', cherry_log: 'Bûche de cerisier',
  bamboo_block: 'Bloc de bambou', crimson_stem: 'Tige cramoisie',
  warped_stem: 'Tige déformée',
  // Nourriture
  bread: 'Pain', wheat: 'Blé', carrot: 'Carotte', potato: 'Pomme de terre',
  apple: 'Pomme', golden_apple: 'Pomme en or',
  enchanted_golden_apple: 'Pomme en or enchantée',
  beef: 'Bœuf cru', cooked_beef: 'Bœuf cuit',
  porkchop: 'Côtelette de porc', cooked_porkchop: 'Côtelette cuite',
  chicken: 'Poulet cru', cooked_chicken: 'Poulet cuit',
  cod: 'Cabillaud', salmon: 'Saumon', tropical_fish: 'Poisson tropical',
  pufferfish: 'Poisson-globe',
  // Mob drops
  bone: 'Os', bone_meal: 'Farine d\'os',
  string: 'Ficelle', spider_eye: 'Œil d\'araignée',
  gunpowder: 'Poudre à canon', rotten_flesh: 'Chair pourrie',
  ender_pearl: 'Perle de l\'Ender', blaze_rod: 'Bâton de Blaze',
  blaze_powder: 'Poudre de Blaze', ghast_tear: 'Larme de Ghast',
  magma_cream: 'Crème de magma', slime_ball: 'Boule de slime',
  leather: 'Cuir', feather: 'Plume', ink_sac: 'Poche d\'encre',
  glow_ink_sac: 'Poche d\'encre brillante',
  prismarine_shard: 'Éclat de prismarine',
  prismarine_crystal: 'Cristal de prismarine',
  nether_star: 'Étoile du Nether', totem_of_undying: 'Totem d\'immortalité',
  shulker_shell: 'Coquille de Shulker', elytra: 'Élytre',
  dragon_breath: 'Souffle de dragon',
  // Nether
  glowstone: 'Pierre lumineuse', glowstone_dust: 'Poudre lumineuse',
  soul_sand: 'Sable des âmes', soul_soil: 'Terre des âmes',
  nether_brick: 'Brique du Nether', nether_wart: 'Verrue du Nether',
  basalt: 'Basalte', blackstone: 'Roche noire',
};

export function getItemDisplayName(type) {
  if (!type) return '—';
  if (NAME_MAP[type]) return NAME_MAP[type];
  // Fallback lisible : "iron_ore" → "Iron Ore"
  return type
    .replace(/_/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase());
}

export function getItemFamily(type) {
  if (!type) return 'unknown';
  const prefixes = ['iron','gold','copper','coal','diamond','emerald','redstone','lapis','quartz','netherite','oak','birch','spruce','jungle','acacia','dark_oak','mangrove','cherry','crimson','warped'];
  for (const p of prefixes) {
    if (type === p || type.startsWith(p + '_') || type === p + '_lazuli') return p;
  }
  return type.split('_')[0];
}

export function isBlock(type)  { return type?.endsWith('_block') ?? false; }
export function isIngot(type)  { return type?.endsWith('_ingot') ?? false; }
export function isTier(type)   { return /_(t[1-4])$/.test(type ?? ''); }
export function getTier(type)  { const m = (type ?? '').match(/_(t([1-4]))$/); return m ? parseInt(m[2]) : null; }
