/**
 * excaliaApi.js — Service API Excalia Economy
 *
 * CORRECTIONS v3 :
 * 1. extractEconomyItems() parcourt récursivement tout le JSON
 * 2. resolveTierPrice() tente PLUSIEURS variantes de noms de tiers
 *    car l'API peut utiliser : iron_t1, iron_compressed_1, iron_compressed_t1, etc.
 * 3. MOCK_DATA inclut maintenant des exemples de tiers compressés
 * 4. buildPriceMap() conserve AUSSI les variantes de noms de tiers
 * 5. getTierCandidateKeys() expose toutes les clés candidates pour le debug
 */

const API_URL   = '/api/excalia/economie';
const CACHE_KEY = 'excalia_slim_v3';
const HIST_KEY  = 'excalia_price_history';
const CUST_KEY  = 'excalia_custom_prices';
const CACHE_TTL = 5 * 60 * 1000;

// Clés racine à ne JAMAIS interpréter comme des items
const ROOT_SKIP_KEYS = new Set(['summary', 'histories', 'history', 'stats', 'meta', 'info']);

// Champs conservés par item dans le cache slim
const SLIM_FIELDS = ['type', 'sellPrice', 'buyPrice', 'sellAmount', 'sellCurrency', 'page', 'slot', 'shopName', 'category'];

// ─── Résolution de l'ID de tier (multi-pattern + fuzzy) ─────────────────────
// L'API Excalia ne nomme pas forcément les tiers comme le fichier recipes.json.
// Cette zone tente donc beaucoup de variantes : anglais, français, compressed,
// tier, t1, tier_1, etc. Le but : trouver le vrai type API sans inventer de prix.
const FAMILY_ALIASES = {
  iron: ['iron', 'fer'],
  gold: ['gold', 'or'],
  copper: ['copper', 'cuivre'],
  coal: ['coal', 'charbon'],
  diamond: ['diamond', 'diamant'],
  emerald: ['emerald', 'emeraude', 'émeraude'],
  redstone: ['redstone'],
  lapis: ['lapis', 'lapis_lazuli', 'lapis-lazuli'],
  quartz: ['quartz', 'nether_quartz'],
  netherite: ['netherite', 'netherite_ingot', 'netherite_ingot']
};

function normalizeKey(key) {
  return String(key ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/^minecraft:/, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function unique(arr) {
  return [...new Set(arr.filter(Boolean))];
}

/**
 * Génère tous les noms possibles qu'un tier peut avoir dans l'API Excalia.
 * Exemples couverts : iron_t1, fer_t1, iron_tier_1, tier_1_iron,
 * compressed_iron_1, iron_compressed_t1, minerai_fer_t1, etc.
 */
export function getTierCandidateKeys(family, tierKey) {
  const n = parseInt(String(tierKey).replace('t', ''), 10); // 1, 2, 3, 4
  const aliases = FAMILY_ALIASES[family] || [family];
  const out = [];

  for (const base of aliases) {
    out.push(
      `${base}_${tierKey}`,
      `${base}_t${n}`,
      `${base}_${n}`,
      `${base}${n}`,
      `${base}_tier_${n}`,
      `${base}_tier_t${n}`,
      `${base}_tier${n}`,
      `${base}_compressed_${n}`,
      `${base}_compressed_t${n}`,
      `${base}_compressed_tier_${n}`,
      `${base}_compress_${n}`,
      `${base}_compress_t${n}`,
      `${base}_c${n}`,
      `compressed_${base}_${n}`,
      `compressed_${base}_t${n}`,
      `compressed_${base}_tier_${n}`,
      `compress_${base}_${n}`,
      `compress_${base}_t${n}`,
      `tier_${n}_${base}`,
      `t${n}_${base}`,
      `minerai_${base}_t${n}`,
      `minerai_${base}_${n}`,
      `mineral_${base}_t${n}`,
      `mineral_${base}_${n}`,
      `${base}_niveau_${n}`,
      `${base}_niv_${n}`,
      `${base}_level_${n}`,
      `${base}_lvl_${n}`
    );
  }

  return unique(out.map(normalizeKey));
}

function tierRegexFor(family, tierKey) {
  const n = parseInt(String(tierKey).replace('t', ''), 10);
  const aliases = (FAMILY_ALIASES[family] || [family]).map(normalizeKey);
  const famPart = aliases.map(a => a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  // Le tier doit être un vrai morceau : t1, tier_1, compressed_1, niveau_1...
  const tierPart = `(t_?${n}|tier_?${n}|compressed_?t?_?${n}|compress_?t?_?${n}|c_?${n}|niveau_?${n}|niv_?${n}|level_?${n}|lvl_?${n})`;
  return new RegExp(`(^|_)(${famPart})(_|$).*${tierPart}($|_)|(^|_)${tierPart}.*(_|^)(${famPart})(_|$)`, 'i');
}

/**
 * Retourne la première clé trouvée dans priceMap parmi les candidats du tier,
 * puis tente une recherche floue sur toutes les clés disponibles.
 */
export function resolveTierPrice(family, tierKey, priceMap) {
  const candidates = getTierCandidateKeys(family, tierKey);
  for (const key of candidates) {
    if (priceMap[key] !== undefined && priceMap[key] !== null) {
      return { key, price: priceMap[key], strategy: 'candidate' };
    }
  }

  const re = tierRegexFor(family, tierKey);
  const allKeys = Object.keys(priceMap || {});
  const found = allKeys.find(k => re.test(normalizeKey(k)) && Number(priceMap[k]) > 0);
  if (found) return { key: found, price: priceMap[found], strategy: 'fuzzy' };

  return null;
}

export function findDetectedTierItems(items = []) {
  const detected = [];
  for (const item of items) {
    const key = normalizeKey(item.type);
    for (const family of Object.keys(FAMILY_ALIASES)) {
      for (const tier of ['t1', 't2', 't3', 't4']) {
        if (tierRegexFor(family, tier).test(key)) {
          detected.push({ ...item, family, tier, normalizedType: key });
        }
      }
    }
  }
  return detected;
}

// ─── Extracteur récursif ───────────────────────────────────────────────────
export function extractEconomyItems(node, context = {}, parentKey = '') {
  if (!node || typeof node !== 'object') return [];

  if (Array.isArray(node)) {
    return node.flatMap((child, i) => extractEconomyItems(child, context, parentKey));
  }

  if (isEconomyItem(node)) {
    return [buildSlimItem(node, context)];
  }

  const results = [];
  for (const [key, value] of Object.entries(node)) {
    if (ROOT_SKIP_KEYS.has(key)) continue;
    if (!value || typeof value !== 'object') continue;
    const childContext = buildContext(key, value, context);
    results.push(...extractEconomyItems(value, childContext, key));
  }
  return results;
}

function isEconomyItem(obj) {
  return (
    typeof obj.type === 'string' &&
    obj.type.length > 0 &&
    !ROOT_SKIP_KEYS.has(obj.type) &&
    (typeof obj.sellPrice === 'number' || typeof obj.buyPrice === 'number')
  );
}

function buildContext(key, value, parentContext) {
  const ctx = { ...parentContext };
  if (typeof value?.page === 'number')     ctx.page     = value.page;
  if (typeof value?.slot === 'number')     ctx.slot     = value.slot;
  if (typeof value?.name === 'string')     ctx.shopName = value.name;
  if (typeof value?.shopName === 'string') ctx.shopName = value.shopName;
  if (typeof key === 'string' && isNaN(Number(key)) && key.length > 2) {
    ctx._section = key;
  }
  return ctx;
}

function buildSlimItem(item, context) {
  const out = {};
  for (const f of SLIM_FIELDS) {
    if (item[f] !== undefined) out[f] = item[f];
  }
  if (out.page === undefined && context.page !== undefined) out.page = context.page;
  if (out.slot === undefined && context.slot !== undefined) out.slot = context.slot;
  if (!out.shopName && context.shopName)   out.shopName = context.shopName;
  if (!out.shopName && context._section)   out.shopName = context._section;
  return out;
}

// ─── Détection automatique de catégories ──────────────────────────────────
const CATEGORY_RULES = [
  { key: 'minerals',  test: /^(iron|gold|copper|coal|diamond|emerald|redstone|lapis|quartz|netherite|ancient_debris|amethyst|raw_iron|raw_gold|raw_copper)(_ore|_ingot|_block|_shard|_lazuli)?$/, label: 'Minerais' },
  { key: 'tiers',     test: /^(iron|gold|copper|coal|diamond|emerald|redstone|lapis|quartz|netherite)(_(compressed?|compress|c))?_?t?[1-4]$/, label: 'Compressés' },
  { key: 'wood',      test: /^(oak|birch|spruce|jungle|acacia|dark_oak|mangrove|cherry|bamboo|crimson|warped)_(log|planks|slab|stairs|door|trapdoor|fence|wood|stripped|button|pressure_plate|sign|boat|chest_boat)?/, label: 'Bois' },
  { key: 'food',      test: /^(bread|wheat|carrot|potato|apple|golden_apple|enchanted_golden_apple|beef|porkchop|chicken|rabbit|mutton|cod|salmon|tropical_fish|pufferfish|cake|cookie|melon|pumpkin|beetroot|mushroom|sweet_berries|glow_berries|honey_bottle|dried_kelp)/, label: 'Agriculture & Nourriture' },
  { key: 'mob_drops', test: /^(bone|bone_meal|string|spider_eye|gunpowder|rotten_flesh|ender_pearl|blaze_rod|blaze_powder|ghast_tear|magma_cream|slime_ball|rabbit_hide|rabbit_foot|feather|leather|ink_sac|glow_ink_sac|prismarine_shard|prismarine_crystal|nautilus_shell|heart_of_the_sea|scute|phantom_membrane|dragon_breath|shulker_shell|totem_of_undying|nether_star|wither_rose)/, label: 'Loots de mobs' },
  { key: 'nether',    test: /^(netherite|ancient_debris|nether_quartz|nether_brick|nether_star|blaze|ghast|magma|soul_sand|soul_soil|glowstone|shroomlight|crimson|warped|basalt|blackstone|gilded_blackstone|piglin|hoglin|strider|nether_wart|nether_gold)/, label: 'Nether' },
  { key: 'end',       test: /^(end_stone|ender_pearl|eye_of_ender|ender_chest|end_crystal|shulker|purpur|chorus|dragon|elytra|end_rod)/, label: 'End' },
  { key: 'gems',      test: /^(diamond|emerald|amethyst|prismarine|lapis_lazuli)/, label: 'Gemmes' },
  { key: 'ingots',    test: /_(ingot|nugget)$/, label: 'Lingots & Nuggets' },
  { key: 'blocks',    test: /_block$/, label: 'Blocs' },
  { key: 'potions',   test: /^(potion|splash_potion|lingering_potion|fermented_spider_eye|brewing_stand|blaze_powder|glowstone_dust|redstone|gunpowder|dragon_breath)/, label: 'Potions & Brassage' },
  { key: 'enchant',   test: /^(enchanted_book|experience_bottle|lapis_lazuli|grindstone|anvil|enchanting_table)/, label: 'Enchantements' },
  { key: 'tools',     test: /_(sword|pickaxe|axe|shovel|hoe|bow|crossbow|trident|shield|helmet|chestplate|leggings|boots|fishing_rod|flint_and_steel|shears|brush)$/, label: 'Outils & Armes' },
  { key: 'boss',      test: /^(wither_skeleton_skull|wither_rose|nether_star|ender_dragon_egg|dragon_egg|elytra|totem_of_undying|beacon)/, label: 'Boss & Rares' },
];

export function detectCategory(type) {
  if (!type) return 'Divers';
  for (const rule of CATEGORY_RULES) {
    if (rule.test.test(type)) return rule.label;
  }
  return 'Divers';
}

export function enrichWithCategories(items) {
  return items.map(item => ({
    ...item,
    category: item.category || detectCategory(item.type),
  }));
}

// ─── Formatage des prix ────────────────────────────────────────────────────
export function formatPrice(price) {
  if (price == null || isNaN(price)) return '—';
  return Number(price).toLocaleString('fr-FR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

// ─── Données mock (activation MANUELLE uniquement) ────────────────────────
// IMPORTANT : les tiers sont inclus ici avec la convention iron_t1, iron_t2...
// Si l'API réelle utilise un autre pattern, la fonction resolveTierPrice() le détectera.
export const MOCK_DATA = [
  // Ressources de base
  { type: 'iron_ingot',        sellPrice: 3,        sellAmount: 1, category: 'Lingots & Nuggets' },
  { type: 'iron_block',        sellPrice: 25,        sellAmount: 1, category: 'Blocs' },
  { type: 'iron_t1',           sellPrice: 1800,      sellAmount: 1, category: 'Compressés' },
  { type: 'iron_t2',           sellPrice: 16000,     sellAmount: 1, category: 'Compressés' },
  { type: 'iron_t3',           sellPrice: 145000,    sellAmount: 1, category: 'Compressés' },
  { type: 'iron_t4',           sellPrice: 1300000,   sellAmount: 1, category: 'Compressés' },

  { type: 'gold_ingot',        sellPrice: 16,        sellAmount: 1, category: 'Lingots & Nuggets' },
  { type: 'gold_block',        sellPrice: 140,       sellAmount: 1, category: 'Blocs' },
  { type: 'gold_t1',           sellPrice: 9500,      sellAmount: 1, category: 'Compressés' },
  { type: 'gold_t2',           sellPrice: 85000,     sellAmount: 1, category: 'Compressés' },
  { type: 'gold_t3',           sellPrice: 765000,    sellAmount: 1, category: 'Compressés' },
  { type: 'gold_t4',           sellPrice: 6900000,   sellAmount: 1, category: 'Compressés' },

  { type: 'copper_ingot',      sellPrice: 1.5,       sellAmount: 1, category: 'Lingots & Nuggets' },
  { type: 'copper_block',      sellPrice: 12,        sellAmount: 1, category: 'Blocs' },
  { type: 'copper_t1',         sellPrice: 870,       sellAmount: 1, category: 'Compressés' },
  { type: 'copper_t2',         sellPrice: 7800,      sellAmount: 1, category: 'Compressés' },
  { type: 'copper_t3',         sellPrice: 70000,     sellAmount: 1, category: 'Compressés' },

  { type: 'diamond',           sellPrice: 67.2,      sellAmount: 1, category: 'Gemmes' },
  { type: 'diamond_block',     sellPrice: 604,       sellAmount: 1, category: 'Blocs' },
  { type: 'diamond_t1',        sellPrice: 39500,     sellAmount: 1, category: 'Compressés' },
  { type: 'diamond_t2',        sellPrice: 355000,    sellAmount: 1, category: 'Compressés' },
  { type: 'diamond_t3',        sellPrice: 3200000,   sellAmount: 1, category: 'Compressés' },
  { type: 'diamond_t4',        sellPrice: 28800000,  sellAmount: 1, category: 'Compressés' },

  { type: 'emerald',           sellPrice: 50,        sellAmount: 1, category: 'Gemmes' },
  { type: 'emerald_block',     sellPrice: 430,       sellAmount: 1, category: 'Blocs' },
  { type: 'emerald_t1',        sellPrice: 29500,     sellAmount: 1, category: 'Compressés' },
  { type: 'emerald_t2',        sellPrice: 265000,    sellAmount: 1, category: 'Compressés' },
  { type: 'emerald_t3',        sellPrice: 2380000,   sellAmount: 1, category: 'Compressés' },

  { type: 'coal',              sellPrice: 1.5,       sellAmount: 1, category: 'Minerais' },
  { type: 'coal_block',        sellPrice: 12,        sellAmount: 1, category: 'Blocs' },
  { type: 'coal_t1',           sellPrice: 870,       sellAmount: 1, category: 'Compressés' },
  { type: 'coal_t2',           sellPrice: 7800,      sellAmount: 1, category: 'Compressés' },
  { type: 'coal_t3',           sellPrice: 70000,     sellAmount: 1, category: 'Compressés' },

  { type: 'lapis_lazuli',      sellPrice: 6,         sellAmount: 1, category: 'Gemmes' },
  { type: 'lapis_block',       sellPrice: 50,        sellAmount: 1, category: 'Blocs' },
  { type: 'lapis_t1',          sellPrice: 3500,      sellAmount: 1, category: 'Compressés' },
  { type: 'lapis_t2',          sellPrice: 31500,     sellAmount: 1, category: 'Compressés' },
  { type: 'lapis_t3',          sellPrice: 283000,    sellAmount: 1, category: 'Compressés' },

  { type: 'redstone',          sellPrice: 4,         sellAmount: 1, category: 'Minerais' },
  { type: 'redstone_block',    sellPrice: 34,        sellAmount: 1, category: 'Blocs' },
  { type: 'redstone_t1',       sellPrice: 2350,      sellAmount: 1, category: 'Compressés' },
  { type: 'redstone_t2',       sellPrice: 21000,     sellAmount: 1, category: 'Compressés' },
  { type: 'redstone_t3',       sellPrice: 189000,    sellAmount: 1, category: 'Compressés' },

  { type: 'quartz',            sellPrice: 7,         sellAmount: 1, category: 'Nether' },
  { type: 'quartz_block',      sellPrice: 25,        sellAmount: 1, category: 'Blocs' },
  { type: 'quartz_t1',         sellPrice: 4100,      sellAmount: 1, category: 'Compressés' },
  { type: 'quartz_t2',         sellPrice: 36900,     sellAmount: 1, category: 'Compressés' },

  { type: 'netherite_ingot',   sellPrice: 350,       sellAmount: 1, category: 'Nether' },
  { type: 'netherite_block',   sellPrice: 3000,      sellAmount: 1, category: 'Nether' },
  { type: 'netherite_t1',      sellPrice: 205000,    sellAmount: 1, category: 'Compressés' },
  { type: 'netherite_t2',      sellPrice: 1850000,   sellAmount: 1, category: 'Compressés' },
];

// ─── localStorage : cache slim ─────────────────────────────────────────────
function saveSlimCache(items) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ data: items, ts: Date.now() }));
    return true;
  } catch (e) {
    console.warn('[Excalia] Cache localStorage échoué (quota?) — données API gardées en mémoire.', e.message);
    return false;
  }
}

function readCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const { data, ts } = JSON.parse(raw);
    return { data, timestamp: ts };
  } catch { return null; }
}

function saveHistory(items) {
  try {
    const hist = JSON.parse(localStorage.getItem(HIST_KEY) || '[]');
    hist.push({
      ts: Date.now(),
      prices: Object.fromEntries(items.filter(i => i.sellPrice != null).map(i => [i.type, i.sellPrice])),
    });
    localStorage.setItem(HIST_KEY, JSON.stringify(hist.slice(-48)));
  } catch {}
}

// ─── Prix personnalisés ────────────────────────────────────────────────────
export function getCustomPrices() {
  try { return JSON.parse(localStorage.getItem(CUST_KEY) || '{}'); } catch { return {}; }
}
export function setCustomPrice(t, p) {
  const c = getCustomPrices();
  const price = Number(p);
  if (!t || Number.isNaN(price) || price < 0) return;
  c[t] = price;
  try { localStorage.setItem(CUST_KEY, JSON.stringify(c)); } catch {}
}
export function removeCustomPrice(t) {
  const c = getCustomPrices(); delete c[t];
  try { localStorage.setItem(CUST_KEY, JSON.stringify(c)); } catch {}
}
export function clearCustomPrices() { localStorage.removeItem(CUST_KEY); }

function applyCustom(items) {
  const custom = getCustomPrices();
  const customEntries = Object.entries(custom)
    .map(([type, price]) => ({ type, price: Number(price) }))
    .filter(({ type, price }) => type && !Number.isNaN(price) && price >= 0);

  if (!customEntries.length) return items;

  const existing = new Set(items.map(i => normalizeKey(i.type)));

  const patched = items.map(i => {
    const exact = custom[i.type];
    const normalized = custom[normalizeKey(i.type)];
    const price = exact !== undefined ? exact : normalized;
    return price !== undefined ? { ...i, sellPrice: Number(price), customPrice: true } : i;
  });

  // Très important pour les T1/T2/T3/T4 : si l'API ne fournit pas l'item tier,
  // mais que le vrai prix a été saisi dans Prix Admin, on ajoute quand même l'item.
  // Ainsi resolveTierPrice('iron','t1', priceMap) peut trouver iron_t1.
  for (const { type, price } of customEntries) {
    const normalized = normalizeKey(type);
    if (!existing.has(normalized)) {
      patched.push({
        type: normalized,
        sellPrice: price,
        sellAmount: 1,
        sellCurrency: 'Skydollars',
        category: detectCategory(normalized),
        customPrice: true,
        source: 'custom',
      });
    }
  }

  return patched;
}

// ─── Fetch principal ───────────────────────────────────────────────────────
export async function fetchEconomyData() {
  // 1. Cache valide ?
  const cached = readCache();
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return { data: applyCustom(cached.data), source: 'cache', fromCache: true, mock: false, timestamp: cached.timestamp };
  }

  // 2. Appel API
  try {
    const res = await fetch(API_URL, {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);

    const rawJson = await res.json();
    const extracted = extractEconomyItems(rawJson);
    if (!extracted.length) throw new Error('Aucun item économique trouvé dans la réponse API');

    const enriched = enrichWithCategories(extracted);
    saveSlimCache(enriched);
    saveHistory(enriched);

    return { data: applyCustom(enriched), source: 'api', fromCache: false, mock: false, timestamp: Date.now(), rawStructure: Object.keys(rawJson) };

  } catch (err) {
    console.error('[Excalia] Erreur fetch:', err.message);

    if (cached) {
      return { data: applyCustom(cached.data), source: 'cache', fromCache: true, stale: true, mock: false, timestamp: cached.timestamp, apiError: err.message };
    }

    return { data: [], source: 'error', fromCache: false, mock: false, apiError: err.message, timestamp: Date.now() };
  }
}

// ─── Mode démo manuel ──────────────────────────────────────────────────────
export function getMockData() {
  return { data: applyCustom(MOCK_DATA), source: 'mock', fromCache: false, mock: true, timestamp: Date.now() };
}

// ─── Utilitaires ──────────────────────────────────────────────────────────
export function clearCache() {
  localStorage.removeItem(CACHE_KEY);
  localStorage.removeItem('excalia_slim_v2'); // nettoyer l'ancienne version aussi
}

export function getPriceHistory() {
  try { return JSON.parse(localStorage.getItem(HIST_KEY) || '[]'); } catch { return []; }
}

export function buildPriceMap(items) {
  const map = {};
  for (const item of items) {
    if (!item.type) continue;
    const price = item.sellPrice ?? null;
    if (price === null || price === undefined || Number.isNaN(Number(price))) continue;

    const exact = item.type;
    const normalized = normalizeKey(item.type);

    // On conserve la clé exacte ET une clé normalisée.
    // Exemple : "minecraft:diamond" devient aussi "diamond".
    map[exact] = Number(price);
    map[normalized] = Number(price);
  }

  // Les prix personnalisés sont aussi injectés directement dans la priceMap.
  // C'est ce qui permet d'avoir les vrais prix des tiers même si l'API ne les expose pas.
  const custom = getCustomPrices();
  for (const [key, value] of Object.entries(custom)) {
    const price = Number(value);
    if (!key || Number.isNaN(price) || price < 0) continue;
    map[key] = price;
    map[normalizeKey(key)] = price;
  }

  return map;
}

export function getItemPrice(items, typeKey) {
  const item = items.find(i => i.type === typeKey);
  return item ? (item.sellPrice ?? 0) : null;
}

export function computeStats(items) {
  if (!items.length) return null;
  const withPrice = items.filter(i => i.sellPrice != null);
  const prices = withPrice.map(i => i.sellPrice);
  const categories = [...new Set(items.map(i => i.category).filter(Boolean))];
  const mostExpensive = withPrice.reduce((a, b) => (a.sellPrice > b.sellPrice ? a : b), withPrice[0]);
  const cheapest = withPrice.reduce((a, b) => (a.sellPrice < b.sellPrice ? a : b), withPrice[0]);
  const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
  return {
    total: items.length,
    withPrice: withPrice.length,
    categories: categories.length,
    categoryList: categories.sort(),
    mostExpensive,
    cheapest,
    avgPrice: avg,
    pages: [...new Set(items.map(i => i.page).filter(v => v != null))].length,
  };
}
