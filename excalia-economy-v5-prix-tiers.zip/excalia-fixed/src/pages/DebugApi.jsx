import React, { useState, useMemo } from 'react';
import { useEconomy } from '../App';
import { formatPrice, computeStats, getTierCandidateKeys, resolveTierPrice, findDetectedTierItems } from '../services/excaliaApi';
import { getItemDisplayName } from '../utils/itemDisplay';
import recipes from '../data/recipes.json';
import { RefreshCw, Copy, CheckCircle, Wifi, WifiOff, AlertTriangle, Database, Code, Layers, Search } from 'lucide-react';

// ─── Détection des items tiers dans les items API ─────────────────────────
function detectTierItems(items) {
  return findDetectedTierItems(items);
}

// ─── Calcule les tiers manquants ─────────────────────────────────────────
function computeMissingTiers(priceMap) {
  const missing = [];
  for (const [familyKey, familyDef] of Object.entries(recipes.families)) {
    for (const tierKey of Object.keys(familyDef.tiers)) {
      const resolved = resolveTierPrice(familyKey, tierKey, priceMap);
      if (!resolved) {
        const candidates = getTierCandidateKeys(familyKey, tierKey);
        missing.push({
          family: familyKey,
          familyLabel: familyDef.label,
          tierKey,
          tierLabel: tierKey.toUpperCase(),
          candidatesTried: candidates,
        });
      }
    }
  }
  return missing;
}

// ─── Calcule les tiers trouvés ──────────────────────────────────────────
function computeFoundTiers(priceMap, items) {
  const found = [];
  for (const [familyKey, familyDef] of Object.entries(recipes.families)) {
    for (const tierKey of Object.keys(familyDef.tiers)) {
      const resolved = resolveTierPrice(familyKey, tierKey, priceMap);
      if (resolved) {
        const item = items.find(i => i.type === resolved.key || String(i.type).toLowerCase() === String(resolved.key).toLowerCase());
        found.push({
          family: familyKey,
          familyLabel: familyDef.label,
          familyEmoji: familyDef.emoji,
          tierKey,
          tierLabel: tierKey.toUpperCase(),
          apiKey: resolved.key,
          strategy: resolved.strategy ?? 'exact',
          sellPrice: resolved.price,
          category: item?.category ?? '—',
        });
      }
    }
  }
  return found;
}

export default function DebugApi() {
  const { items, priceMap, debugData, dataSource, apiError, lastUpdate, loadData, loading, rawStructure } = useEconomy();
  const [copied, setCopied] = useState(false);
  const [showRaw, setShowRaw] = useState(false);
  const [showAllItems, setShowAllItems] = useState(false);

  const stats = useMemo(() => computeStats(items), [items]);

  const tierItems = useMemo(() => detectTierItems(items), [items]);
  const missingTiers = useMemo(() => computeMissingTiers(priceMap ?? {}), [priceMap]);
  const foundTiers = useMemo(() => computeFoundTiers(priceMap ?? {}, items), [priceMap, items]);

  const cacheSize = useMemo(() => {
    try {
      const v = localStorage.getItem('excalia_slim_v3') || localStorage.getItem('excalia_slim_v2');
      return v ? (new Blob([v]).size / 1024).toFixed(1) + ' KB' : '—';
    } catch { return '—'; }
  }, [items]);

  const statusInfo = {
    api:   { label: 'API connectée',  color: 'profit-badge-positive', icon: Wifi },
    cache: { label: 'Cache local',    color: 'profit-badge-neutral',  icon: Database },
    mock:  { label: 'Mode démo',      color: 'profit-badge-neutral',  icon: WifiOff },
    error: { label: 'Erreur API',     color: 'profit-badge-negative', icon: AlertTriangle },
  }[dataSource] ?? { label: '—', color: 'profit-badge-neutral', icon: Wifi };

  const copyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(debugData ?? items, null, 2)).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const displayedItems = showAllItems ? items : items.slice(0, 50);

  return (
    <div className="space-y-6">
      <div className="fade-in-up">
        <h2 className="font-display text-xl font-bold text-white tracking-wider">DEBUG API</h2>
        <p className="text-slate-400 text-sm">Diagnostic complet — connexion Excalia & détection des tiers</p>
      </div>

      {/* Statut */}
      <div className="hex-card p-5 fade-in-up">
        <h3 className="font-display text-xs text-crystal-400 tracking-widest mb-4">STATUT</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-xs text-slate-500 mb-1">Source</p>
            <span className={`${statusInfo.color} flex items-center gap-1 w-fit`}>
              <statusInfo.icon size={10} />{statusInfo.label}
            </span>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Items extraits</p>
            <p className="font-display text-xl font-bold text-white">{items.length}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Catégories</p>
            <p className="font-display text-xl font-bold text-white">{stats?.categories ?? 0}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Cache localStorage</p>
            <p className="text-sm font-mono text-white">{cacheSize}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-xs text-slate-500 mb-1">URL utilisée</p>
            <p className="text-xs font-mono text-crystal-400">/api/excalia/economie</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Dernier refresh</p>
            <p className="text-xs font-mono text-white">
              {lastUpdate ? new Date(lastUpdate).toLocaleString('fr-FR') : '—'}
            </p>
          </div>
          {rawStructure && (
            <div className="col-span-2">
              <p className="text-xs text-slate-500 mb-1">Clés racine de l'API</p>
              <p className="text-xs font-mono text-slate-300">[{rawStructure.join(', ')}]</p>
            </div>
          )}
        </div>
        {apiError && (
          <div className="p-3 rounded-lg mb-4" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
            <p className="text-xs text-red-400 font-mono">{apiError}</p>
          </div>
        )}
        <div className="flex gap-3 flex-wrap">
          <button className="btn-primary text-xs py-1.5 px-3" onClick={() => loadData(true)} disabled={loading}>
            <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Actualiser API
          </button>
          <button className="btn-secondary text-xs py-1.5 px-3" onClick={copyJson}>
            {copied ? <CheckCircle size={13} className="text-emerald-400" /> : <Copy size={13} />}
            {copied ? 'Copié !' : 'Copier JSON extrait'}
          </button>
          <button className="btn-secondary text-xs py-1.5 px-3" onClick={() => setShowRaw(!showRaw)}>
            <Code size={13} /> {showRaw ? 'Masquer' : 'Voir'} JSON brut
          </button>
        </div>
      </div>

      {/* ─── SECTION : Items Tiers détectés ─────────────────────────────── */}
      <div className="hex-card p-5 fade-in-up">
        <h3 className="font-display text-xs text-crystal-400 tracking-widest mb-1 flex items-center gap-2">
          <Layers size={13} />
          ITEMS TIERS DÉTECTÉS ({foundTiers.length} tiers trouvés)
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Items reconnus comme tiers compressés dans le priceMap actuel. Affiche le nom brut exact de l'API.
        </p>

        {foundTiers.length === 0 ? (
          <div className="p-4 rounded-lg text-center" style={{ background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.2)' }}>
            <AlertTriangle size={20} className="text-amber-400 mx-auto mb-2" />
            <p className="text-amber-300 text-sm font-semibold">Aucun tier trouvé dans l'API</p>
            <p className="text-slate-500 text-xs mt-1">
              Le site cherche des clés comme <code className="font-mono bg-slate-800 px-1 rounded">iron_t1</code>, <code className="font-mono bg-slate-800 px-1 rounded">iron_compressed_1</code>...
              mais aucune n'est présente dans les données actuelles.
            </p>
            {dataSource === 'mock' && (
              <p className="text-emerald-400 text-xs mt-2">⚠ En mode démo : les tiers sont disponibles (iron_t1, iron_t2...). Activez le mode démo pour les voir.</p>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-700/50 text-slate-400 font-display tracking-widest">
                  <th className="text-left py-2 pr-3">FAMILLE</th>
                  <th className="text-left py-2 pr-3">TIER</th>
                  <th className="text-left py-2 pr-3">NOM BRUT API (type exact)</th>
                  <th className="text-right py-2 pr-3">PRIX VENTE</th>
                  <th className="text-left py-2 pr-3">CATÉGORIE</th>
                </tr>
              </thead>
              <tbody>
                {foundTiers.map((t, i) => (
                  <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/20">
                    <td className="py-2 pr-3 text-white font-semibold">{t.familyEmoji} {t.familyLabel}</td>
                    <td className="py-2 pr-3">
                      <span className="px-2 py-0.5 rounded text-xs font-display font-bold bg-crystal-500/15 text-crystal-300 border border-crystal-500/25">
                        {t.tierLabel}
                      </span>
                    </td>
                    <td className="py-2 pr-3 font-mono text-emerald-400">{t.apiKey}</td>
                    <td className="py-2 pr-3 text-right font-mono text-white font-bold">
                      {formatPrice(t.sellPrice)}€
                    </td>
                    <td className="py-2 pr-3 text-slate-400">{t.category}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Items avec pattern de tier trouvés mais pas encore reconnus */}
        {tierItems.length > 0 && (
          <div className="mt-4 p-3 rounded-lg" style={{ background: 'rgba(14,165,233,0.05)', border: '1px solid rgba(14,165,233,0.15)' }}>
            <p className="text-xs text-crystal-400 font-semibold mb-2 flex items-center gap-1">
              <Search size={11} /> Items détectés comme compressés par pattern ({tierItems.length})
            </p>
            <div className="flex flex-wrap gap-1.5">
              {tierItems.map((item, i) => (
                <span key={i} className="font-mono text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                  {item.type} → {formatPrice(item.sellPrice)}€
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ─── SECTION : Tiers manquants ──────────────────────────────────── */}
      <div className="hex-card p-5 fade-in-up">
        <h3 className="font-display text-xs text-crystal-400 tracking-widest mb-1 flex items-center gap-2">
          <AlertTriangle size={13} className="text-amber-400" />
          TIERS MANQUANTS ({missingTiers.length} / {Object.values(recipes.families).reduce((s, f) => s + Object.keys(f.tiers).length, 0)} tiers)
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Tiers recherchés mais non trouvés dans l'API — toutes les clés candidates ont été essayées.
        </p>

        {missingTiers.length === 0 ? (
          <div className="p-3 rounded-lg flex items-center gap-3" style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.2)' }}>
            <CheckCircle size={16} className="text-emerald-400 flex-shrink-0" />
            <p className="text-emerald-300 text-sm">Tous les tiers sont trouvés dans l'API !</p>
          </div>
        ) : (
          <div className="space-y-2">
            {missingTiers.map((m, i) => (
              <div key={i} className="p-3 rounded-lg" style={{ background: 'rgba(245,158,11,0.05)', border: '1px solid rgba(245,158,11,0.15)' }}>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-amber-400 font-semibold text-xs">{m.familyLabel} {m.tierLabel}</span>
                  <span className="text-slate-600 text-xs">— non trouvé</span>
                </div>
                <p className="text-xs text-slate-500 mb-1">Clés essayées :</p>
                <div className="flex flex-wrap gap-1">
                  {m.candidatesTried.map((k, j) => (
                    <code key={j} className="text-xs font-mono bg-slate-900 text-red-400 px-1.5 py-0.5 rounded border border-red-900/40">
                      {k}
                    </code>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Catégories trouvées */}
      {stats?.categoryList?.length > 0 && (
        <div className="hex-card p-5 fade-in-up">
          <h3 className="font-display text-xs text-crystal-400 tracking-widest mb-3">
            CATÉGORIES DÉTECTÉES ({stats.categoryList.length})
          </h3>
          <div className="flex flex-wrap gap-2">
            {stats.categoryList.map(cat => (
              <span key={cat} className="profit-badge-neutral text-xs">{cat}</span>
            ))}
          </div>
        </div>
      )}

      {/* Table des items */}
      <div className="hex-card p-5 fade-in-up">
        <h3 className="font-display text-xs text-crystal-400 tracking-widest mb-4">
          ITEMS EXTRAITS ({items.length})
        </h3>
        {items.length === 0 ? (
          <p className="text-slate-500 text-sm">Aucun item chargé.</p>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-700/50 text-slate-400 font-display tracking-widest">
                    <th className="text-left py-2 pr-3">TYPE (API)</th>
                    <th className="text-left py-2 pr-3">NOM AFFICHÉ</th>
                    <th className="text-right py-2 pr-3">PRIX BRUT</th>
                    <th className="text-right py-2 pr-3">AFFICHÉ</th>
                    <th className="text-left py-2 pr-3">CATÉGORIE</th>
                    <th className="text-left py-2">SOURCE</th>
                  </tr>
                </thead>
                <tbody>
                  {displayedItems.map((item, i) => {
                    const isTier = /^(iron|gold|copper|coal|diamond|emerald|redstone|lapis|quartz|netherite).*(t[1-4]|[1-4])$/i.test(item.type ?? '');
                    return (
                      <tr key={i} className={`border-b border-slate-800/50 hover:bg-slate-800/20 ${isTier ? 'bg-crystal-500/5' : ''}`}>
                        <td className="py-2 pr-3 font-mono text-crystal-400">
                          {item.type ?? '—'}
                          {isTier && <span className="ml-1 text-crystal-500 text-xs">⬆</span>}
                        </td>
                        <td className="py-2 pr-3 text-white">{getItemDisplayName(item.type)}</td>
                        <td className="py-2 pr-3 text-right font-mono text-slate-300">{item.sellPrice ?? '—'}</td>
                        <td className="py-2 pr-3 text-right font-mono text-emerald-400">
                          {item.sellPrice != null ? formatPrice(item.sellPrice) + '€' : '—'}
                        </td>
                        <td className="py-2 pr-3 text-slate-400">{item.category ?? '—'}</td>
                        <td className="py-2">
                          <span className={dataSource === 'mock' ? 'profit-badge-neutral' : 'profit-badge-positive'} style={{ fontSize: '10px' }}>
                            {dataSource === 'mock' ? 'démo' : 'API'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {items.length > 50 && (
              <button
                className="btn-secondary text-xs py-1.5 px-3 mt-3"
                onClick={() => setShowAllItems(!showAllItems)}
              >
                {showAllItems ? `Réduire (afficher 50)` : `Voir tous les ${items.length} items`}
              </button>
            )}
          </>
        )}
      </div>

      {/* JSON brut */}
      {showRaw && (
        <div className="hex-card p-5 fade-in-up">
          <h3 className="font-display text-xs text-crystal-400 tracking-widest mb-3">
            JSON EXTRAIT (mémoire — non sauvegardé en localStorage)
          </h3>
          <pre className="text-xs text-slate-400 font-mono overflow-auto max-h-80 bg-black/30 p-3 rounded-lg">
            {JSON.stringify(debugData ?? items, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
